<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Task</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 24px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        button {
            background-color: #4caf50;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
}
    </style>
</head>
<body>



<form action="index3.php" method="post">
    <label for="userid">User ID:</label>
    <input type="text" id="userid" name="userid" required>

    <label for="taskid">Task ID:</label>
    <input type="text" id="taskid" name="taskid" required>

    <label for="taskname">Task Name:</label>
    <input type="text" id="taskname" name="taskname" required>

    <label for="date">Date:</label>
    <input type="date" id="date" name="date" required>

    <label for="time">Time:</label>
    <input type="time" id="time" name="time" required>


    <button type="submit" name="submit1">Create Task</button>
    <?php
    if(isset($_POST['submit1'])){
                $ti = $_POST['taskid'];
                $ui = $_POST['userid'];
                $tn = $_POST['taskname'];
                $dt = $_POST['date'];
                $tm = $_POST['time'];
                include 'connection.php';
                $que = "INSERT INTO taskmn values('$ti','$ui','$tn','$dt','$tm')";
                $res = mysqli_query($con,$que);
                if($res){
                    echo "Task creation Successful!!!";
                }
                else{
                    echo "database error";
                }
            }
            ?>

</form>

</body>
</html>
