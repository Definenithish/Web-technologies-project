<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Tasks</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #0074cc;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #005b99;
        }
    </style>
</head>
<body>

<form action="index5.php" method="post">
    <label for="userid">User ID:</label>
    <input type="text" id="userid" name="userid" required>
    <?php
    if(isset($_POST['submit1'])){
                $ui = $_POST['userid'];
                include 'connection.php';
                $que = "select * from taskmn where userid='$ui'";
                $res = mysqli_query($con,$que);
                if($res){
                    echo "";
                }
                else{
                    echo "database error";
                }
               
            }
            ?>

</form>

</body>
</html>
