<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs (you might want to enhance this based on your requirements)
    $taskName = htmlspecialchars($_POST["taskName"]);
    $taskDescription = htmlspecialchars($_POST["taskDescription"]);

    // Store the task details in a file (you might use a database in a real-world scenario)
    $taskData = "Task Name: $taskName\nTask Description: $taskDescription\n\n";

    // Append to a file (you might want to use a database instead)
    file_put_contents('tasks.txt', $taskData, FILE_APPEND);

    echo "Task details submitted successfully.";
} else {
    // Redirect to the form if accessed directly
    header("Location: index.html");
    exit();
}
?>