<?php
    function isloggedid() {
        session_start();
        if(isset($_SESSION['userid'])){
            return TRUE;
        }
        else{
            return FALSE;
        }
    }
?>