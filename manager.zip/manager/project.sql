-- Create a new database (if it doesn't exist)
CREATE DATABASE IF NOT EXISTS wt;

-- Switch to the new database
USE wt;

-- Create the register_table only if it doesn't exist
CREATE TABLE IF NOT EXISTS register_table (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    password VARCHAR(255) NOT NULL
);
