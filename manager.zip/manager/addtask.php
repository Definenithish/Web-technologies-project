<?php 
    include './function.php';
    include './connection.php';
    if(!isloggedid()){
        echo "not logged in";
    }
    else{ 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Task Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #81d6eb;
        }

        header {
            background-color: #da0b0b;
            color: #fff;
            padding: 1em;
            text-align: center;
        }
        /* body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        } */

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #333;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 24px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        button {
            background-color: #4caf50;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
}

    </style>
</head>
<body>
    <header>
        <h1>Online Task Manager</h1>
    </header>
    <a class="btn btn-primary mt-3 ms-5" href="main.php">Home</a>
    <form action="addtask.php" method="post" class="m-5">
    <input type="text" id="userid" name="userid" required hidden value="<?php echo $_SESSION['userid']?>">

    <label for="taskid">Task ID:</label>
    <input type="text" id="taskid" name="taskid" required>

    <label for="taskname">Task Name:</label>
    <input type="text" id="taskname" name="taskname" required>

    <label for="date">Date:</label>
    <input type="date" id="date" name="date" required>

    <label for="time">Time:</label>
    <input type="time" id="time" name="time" required>


    <button type="submit" name="submit1">Add Task</button>
    <?php
    if(isset($_POST['submit1'])){
                $ti = $_POST['taskid'];
                $ui = $_POST['userid'];
                $tn = $_POST['taskname'];
                $dt = $_POST['date'];
                $tm = $_POST['time'];
                include 'connection.php';
                $que = "INSERT INTO taskmn values('$ti','$ui','$tn','$dt','$tm')";
                $res = mysqli_query($con,$que);
                if($res){
                    echo "Task creation Successful!!!";
                }
                else{
                    echo "database error";
                }
            }
            ?>

</form>
</body>
</html>
<?php
    }
?>