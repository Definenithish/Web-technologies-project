show databases;
use wt;
show tables;
select * from register_table;
desc register_table;

CREATE TABLE register (
    user_id varchar(50) PRIMARY KEY,
    password VARCHAR(255) NOT NULL
);

select * from register;
create table taskmn (
taskid int primary key,userid varchar(50), name varchar(30),date date,time time,foreign key (userid) references register(user_id));
desc taskmn;
select * from taskmn;
alter table taskmn drop primary key;
 




