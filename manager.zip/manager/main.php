
<?php 
    include './function.php';
    include './connection.php';
    if(!isloggedid()){
        echo "not logged in";
    }
    else{
        // print_r($_SESSION);
        if(isset($_GET['command'])){
            $que = "DELETE FROM taskmn where userid='$_SESSION[userid]' and taskid='$_GET[taskid]'";
            $res = mysqli_query($con,$que);
            if(!$res){
                echo "<div class='alert alert-danger m-2 p-2'>Failed to remove</div>";
            }
        }
        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Task Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #81d6eb;
        }

        header {
            background-color: #da0b0b;
            color: #fff;
            padding: 1em;
            text-align: center;
        }

    </style>
</head>
<body>
    <header>
        <h1>Online Task Manager</h1>
    </header>

    <!-- <a href="index3.php"><button class="button">Create</button></a>
    <a href="index4.php"><button class="button delete">Delete</button></a>
    <a href="index5.php"><button class="button view"> View </button></a> -->

    <div class="mx-5 mt-5">
        <div style="display:flex; justify-content: space-between;">
            <a href="addtask.php" class="btn btn-success">Add Task</a>
            <div>USER ID : <?php echo $_SESSION['userid']; ?></div>
            <a href="logout.php" class="btn btn-danger">Logout</a>
        </div>
    </div>
    <div class="card m-5">
        <div class="card-header">Tasks</div>
        <div class="card-item">
        <table class="table">
  <thead>
    <tr>
      <th scope="col" hidden>Task id</th>
      <th scope="col">Task</th>
      <th scope="col">Date</th>
      <th scope="col">Time</th>
      <th scope="col">Mark as Done</th>
    </tr>
  </thead>
  <tbody>
        <?php
            $query = "SELECT * FROM taskmn WHERE userid='$_SESSION[userid]'";
            $res = mysqli_query($con,$query);
            if($res){
                while($row = mysqli_fetch_assoc($res)){
                    ?>
                        <tr>
                            <th scope="row" hidden><?php echo $row['taskid']; ?></th>
                            <td><?php echo $row['name']?></td>
                            <td><?php echo $row['date']?></td>
                            <td><?php echo $row['time']?></td>
                            <td><a href="main.php?command=complete&taskid=<?php echo $row['taskid'];?>" class="btn btn-secondary">Completed</a></td>
                        </tr>
                    <?php
                }
            }
            else{
                echo "SQL ERROR";
            }
        ?>

    </tbody>
    </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>

<?php
    }
    ?>