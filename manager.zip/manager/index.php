<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css.css">
    <title>Task Manager</title>
</head>
<body>
    <div class="container">
        <form id="registerForm" action="index.php" method="post">
            <h2>Register</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit" name="submit1">Register</button>
            <?php
            if(isset($_POST['submit1'])){
                $un = $_POST['username'];
                $pw = $_POST['password'];
                include 'connection.php';
                $que1 = "select * from register where user_id = '$un'";
                $res1 = mysqli_query($con,$que1);
                if($res1){
                    if(mysqli_num_rows($res1)>0){
                        echo "Username already exists";
                    }
                    else{
                        $que = "INSERT INTO register values('$un','$pw')";
                        $res = mysqli_query($con,$que);
                        if($res){
                            echo "Registration Successful!!!";
                        }
                        else{
                            echo "database error";
                        }
                    }
                }
                else{
                    echo "database error";
                }
            }
            ?>
        </form>

        <form id="loginForm" action="index.php" method="post">
            <h2>Login</h2>
            <label for="Username">Username:</label>
            <input type="text" id="Username" name="loginUsername" required>
            <label for="Password">Password:</label>
            <input type="password" id="Password" name="loginPassword" required>
            <button type="submit" name="submit2" value="submit2">Login</button>
            <?php
            if(isset($_POST['submit2'])){
                $lun = $_POST['loginUsername'];
                $lpass = $_POST['loginPassword'];
                include 'connection.php';
                $aue = "SELECT * from register where user_id='$lun' and password='$lpass'";
                $resu = mysqli_query($con,$aue);
                if($resu){
                    if(mysqli_num_rows($resu)<1){
                        echo "Invalid username or password";
                    }
                    else{
                    $row = mysqli_fetch_assoc($resu);
                      session_start();
                    //  echo $row['user_id'];
                    //  echo $row['password'];
                     $_SESSION['userid'] = $row['user_id'];
                    //  echo "<br>".$_SESSION['userid']."<br>";
                    //echo "<script>location='index2.php'</script>";

                    echo "<script>location='main.php'</script>";
                    }
                }
                else{
                    echo "database error";
                }
            }
            else{
               // echo "not submitted";
            }
            ?>
        </form>
    </div>

</body>
</html>
