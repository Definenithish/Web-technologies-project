<?php
    $sn = "localhost:3306";
    $username="root";
    $password="Nidhi@27022003";
    $database="wt";
    $con=mysqli_connect($sn,$username,$password,$database);

    if($con){
        // echo"connection success ";
    }
else{
    // echo"connection failed";
}
?>
