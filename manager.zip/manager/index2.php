<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Task Manager</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #81d6eb;
        }

        header {
            background-color: #da0b0b;
            color: #fff;
            padding: 1em;
            text-align: center;
        }

        button {
            display: block;
            margin: 40px auto;
            padding: 60px 80px;
            font-size: 90px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            outline: none;
            color: #fff;
            background-color: #4CAF50;
            border: none;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .button:hover {
            background-color: #45a049;
        }

        .button.delete {
            background-color: #f44336;
        }

        .button.delete:hover {
            background-color:#d32f2f ;
        }

        .button.view {
            background-color: #2196F3;
        }

        .button.view:hover {
            background-color: #0d47a1;
        }

    </style>
</head>
<body>
    <header>
        <h1>Online Task Manager</h1>
    </header>

    <a href="index3.php"><button class="button">Create</button></a>
    <a href="index4.php"><button class="button delete">Delete</button></a>
    <a href="index5.php"><button class="button view"> View </button></a>
    

    
</body>
</html>